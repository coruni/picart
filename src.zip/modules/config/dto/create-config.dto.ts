export class CreateConfigDto {}
