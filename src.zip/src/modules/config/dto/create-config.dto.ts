export class CreateConfigDto {}
